<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    .suu{
      color: white;
      
      
      border-bottom: 2px solid red;
      border-radius: 10px;
      width: 200px;
      margin-left: 500px;
      text-align: center;
      
    }
    body{
      background-color: black;

    }
  </style>
</head>
<body>
 
  <h1 class="suu">SUCCESS</h1>
  img
 
</body>
</html>